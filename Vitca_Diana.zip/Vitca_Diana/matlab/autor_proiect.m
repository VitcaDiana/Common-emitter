function autor_proiect
open('autor_proiect.pdf')