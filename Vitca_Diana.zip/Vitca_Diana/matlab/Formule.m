function Formule
open('formule_folosite.pdf');