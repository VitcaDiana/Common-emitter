clear all;
close all;
clc;

Ao=0;
A=5;
f=50;
N=5;
RB1=49000;
RB2=22000;
RC=2000;
RE=2500;
beta=100;
VAl=12;
val=1;
tip=1;
VBE=0.6;
Proiect(Ao,A,f,N,RB1,RB2,RC,RE,beta,VAl,val,tip);