function bibliografie
open('Bibliografie.pdf');